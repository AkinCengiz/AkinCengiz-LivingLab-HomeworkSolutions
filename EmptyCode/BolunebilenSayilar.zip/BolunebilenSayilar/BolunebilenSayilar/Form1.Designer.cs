﻿namespace BolunebilenSayilar
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lstMod2 = new System.Windows.Forms.ListBox();
			this.lstMod3 = new System.Windows.Forms.ListBox();
			this.lstMod4 = new System.Windows.Forms.ListBox();
			this.lstMod5 = new System.Windows.Forms.ListBox();
			this.lstMod9 = new System.Windows.Forms.ListBox();
			this.lstMod6 = new System.Windows.Forms.ListBox();
			this.lstMod7 = new System.Windows.Forms.ListBox();
			this.lstMod8 = new System.Windows.Forms.ListBox();
			this.gbxModList = new System.Windows.Forms.GroupBox();
			this.btnMod9 = new System.Windows.Forms.Button();
			this.gbxModAl = new System.Windows.Forms.GroupBox();
			this.btnMod8 = new System.Windows.Forms.Button();
			this.btnMod7 = new System.Windows.Forms.Button();
			this.btnMod6 = new System.Windows.Forms.Button();
			this.btnMod5 = new System.Windows.Forms.Button();
			this.btnMod4 = new System.Windows.Forms.Button();
			this.btnMod3 = new System.Windows.Forms.Button();
			this.btnMod2 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.gbxModList.SuspendLayout();
			this.gbxModAl.SuspendLayout();
			this.SuspendLayout();
			// 
			// lstMod2
			// 
			this.lstMod2.FormattingEnabled = true;
			this.lstMod2.Location = new System.Drawing.Point(6, 19);
			this.lstMod2.Name = "lstMod2";
			this.lstMod2.Size = new System.Drawing.Size(120, 173);
			this.lstMod2.TabIndex = 0;
			// 
			// lstMod3
			// 
			this.lstMod3.FormattingEnabled = true;
			this.lstMod3.Location = new System.Drawing.Point(132, 19);
			this.lstMod3.Name = "lstMod3";
			this.lstMod3.Size = new System.Drawing.Size(120, 173);
			this.lstMod3.TabIndex = 1;
			// 
			// lstMod4
			// 
			this.lstMod4.FormattingEnabled = true;
			this.lstMod4.Location = new System.Drawing.Point(258, 19);
			this.lstMod4.Name = "lstMod4";
			this.lstMod4.Size = new System.Drawing.Size(120, 173);
			this.lstMod4.TabIndex = 2;
			// 
			// lstMod5
			// 
			this.lstMod5.FormattingEnabled = true;
			this.lstMod5.Location = new System.Drawing.Point(384, 19);
			this.lstMod5.Name = "lstMod5";
			this.lstMod5.Size = new System.Drawing.Size(120, 173);
			this.lstMod5.TabIndex = 3;
			// 
			// lstMod9
			// 
			this.lstMod9.FormattingEnabled = true;
			this.lstMod9.Location = new System.Drawing.Point(384, 198);
			this.lstMod9.Name = "lstMod9";
			this.lstMod9.Size = new System.Drawing.Size(120, 173);
			this.lstMod9.TabIndex = 4;
			// 
			// lstMod6
			// 
			this.lstMod6.FormattingEnabled = true;
			this.lstMod6.Location = new System.Drawing.Point(6, 198);
			this.lstMod6.Name = "lstMod6";
			this.lstMod6.Size = new System.Drawing.Size(120, 173);
			this.lstMod6.TabIndex = 6;
			// 
			// lstMod7
			// 
			this.lstMod7.FormattingEnabled = true;
			this.lstMod7.Location = new System.Drawing.Point(132, 198);
			this.lstMod7.Name = "lstMod7";
			this.lstMod7.Size = new System.Drawing.Size(120, 173);
			this.lstMod7.TabIndex = 7;
			// 
			// lstMod8
			// 
			this.lstMod8.FormattingEnabled = true;
			this.lstMod8.Location = new System.Drawing.Point(258, 198);
			this.lstMod8.Name = "lstMod8";
			this.lstMod8.Size = new System.Drawing.Size(120, 173);
			this.lstMod8.TabIndex = 8;
			// 
			// gbxModList
			// 
			this.gbxModList.Controls.Add(this.lstMod2);
			this.gbxModList.Controls.Add(this.lstMod8);
			this.gbxModList.Controls.Add(this.lstMod3);
			this.gbxModList.Controls.Add(this.lstMod7);
			this.gbxModList.Controls.Add(this.lstMod4);
			this.gbxModList.Controls.Add(this.lstMod6);
			this.gbxModList.Controls.Add(this.lstMod9);
			this.gbxModList.Controls.Add(this.lstMod5);
			this.gbxModList.Location = new System.Drawing.Point(12, 48);
			this.gbxModList.Name = "gbxModList";
			this.gbxModList.Size = new System.Drawing.Size(508, 381);
			this.gbxModList.TabIndex = 9;
			this.gbxModList.TabStop = false;
			this.gbxModList.Text = "Tam Bölünen Sayılar";
			// 
			// btnMod9
			// 
			this.btnMod9.Location = new System.Drawing.Point(15, 335);
			this.btnMod9.Name = "btnMod9";
			this.btnMod9.Size = new System.Drawing.Size(115, 35);
			this.btnMod9.TabIndex = 10;
			this.btnMod9.Text = "Mod 9";
			this.btnMod9.UseVisualStyleBackColor = true;
			// 
			// gbxModAl
			// 
			this.gbxModAl.Controls.Add(this.btnMod2);
			this.gbxModAl.Controls.Add(this.btnMod3);
			this.gbxModAl.Controls.Add(this.btnMod4);
			this.gbxModAl.Controls.Add(this.btnMod5);
			this.gbxModAl.Controls.Add(this.btnMod6);
			this.gbxModAl.Controls.Add(this.btnMod7);
			this.gbxModAl.Controls.Add(this.btnMod8);
			this.gbxModAl.Controls.Add(this.btnMod9);
			this.gbxModAl.Location = new System.Drawing.Point(538, 48);
			this.gbxModAl.Name = "gbxModAl";
			this.gbxModAl.Size = new System.Drawing.Size(147, 381);
			this.gbxModAl.TabIndex = 11;
			this.gbxModAl.TabStop = false;
			this.gbxModAl.Text = "Mod Alma İşlemleri";
			// 
			// btnMod8
			// 
			this.btnMod8.Location = new System.Drawing.Point(15, 290);
			this.btnMod8.Name = "btnMod8";
			this.btnMod8.Size = new System.Drawing.Size(115, 35);
			this.btnMod8.TabIndex = 11;
			this.btnMod8.Text = "Mod 8";
			this.btnMod8.UseVisualStyleBackColor = true;
			// 
			// btnMod7
			// 
			this.btnMod7.Location = new System.Drawing.Point(15, 245);
			this.btnMod7.Name = "btnMod7";
			this.btnMod7.Size = new System.Drawing.Size(115, 35);
			this.btnMod7.TabIndex = 12;
			this.btnMod7.Text = "Mod 7";
			this.btnMod7.UseVisualStyleBackColor = true;
			// 
			// btnMod6
			// 
			this.btnMod6.Location = new System.Drawing.Point(15, 200);
			this.btnMod6.Name = "btnMod6";
			this.btnMod6.Size = new System.Drawing.Size(115, 35);
			this.btnMod6.TabIndex = 13;
			this.btnMod6.Text = "Mod 6";
			this.btnMod6.UseVisualStyleBackColor = true;
			// 
			// btnMod5
			// 
			this.btnMod5.Location = new System.Drawing.Point(15, 155);
			this.btnMod5.Name = "btnMod5";
			this.btnMod5.Size = new System.Drawing.Size(115, 35);
			this.btnMod5.TabIndex = 14;
			this.btnMod5.Text = "Mod 5";
			this.btnMod5.UseVisualStyleBackColor = true;
			// 
			// btnMod4
			// 
			this.btnMod4.Location = new System.Drawing.Point(15, 110);
			this.btnMod4.Name = "btnMod4";
			this.btnMod4.Size = new System.Drawing.Size(115, 35);
			this.btnMod4.TabIndex = 15;
			this.btnMod4.Text = "Mod 4";
			this.btnMod4.UseVisualStyleBackColor = true;
			// 
			// btnMod3
			// 
			this.btnMod3.Location = new System.Drawing.Point(15, 65);
			this.btnMod3.Name = "btnMod3";
			this.btnMod3.Size = new System.Drawing.Size(115, 35);
			this.btnMod3.TabIndex = 16;
			this.btnMod3.Text = "Mod 3";
			this.btnMod3.UseVisualStyleBackColor = true;
			// 
			// btnMod2
			// 
			this.btnMod2.Location = new System.Drawing.Point(15, 20);
			this.btnMod2.Name = "btnMod2";
			this.btnMod2.Size = new System.Drawing.Size(115, 35);
			this.btnMod2.TabIndex = 17;
			this.btnMod2.Text = "Mod 2";
			this.btnMod2.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.Location = new System.Drawing.Point(55, 13);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(575, 30);
			this.label1.TabIndex = 12;
			this.label1.Text = "1-100 Arası 2 ile 9 arasındaki sayılara tam bölünenler";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightSeaGreen;
			this.ClientSize = new System.Drawing.Size(692, 437);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.gbxModAl);
			this.Controls.Add(this.gbxModList);
			this.Name = "Form1";
			this.Text = "Mod Alma Formu";
			this.gbxModList.ResumeLayout(false);
			this.gbxModAl.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ListBox lstMod2;
		private System.Windows.Forms.ListBox lstMod3;
		private System.Windows.Forms.ListBox lstMod4;
		private System.Windows.Forms.ListBox lstMod5;
		private System.Windows.Forms.ListBox lstMod9;
		private System.Windows.Forms.ListBox lstMod6;
		private System.Windows.Forms.ListBox lstMod7;
		private System.Windows.Forms.ListBox lstMod8;
		private System.Windows.Forms.GroupBox gbxModList;
		private System.Windows.Forms.Button btnMod9;
		private System.Windows.Forms.GroupBox gbxModAl;
		private System.Windows.Forms.Button btnMod2;
		private System.Windows.Forms.Button btnMod3;
		private System.Windows.Forms.Button btnMod4;
		private System.Windows.Forms.Button btnMod5;
		private System.Windows.Forms.Button btnMod6;
		private System.Windows.Forms.Button btnMod7;
		private System.Windows.Forms.Button btnMod8;
		private System.Windows.Forms.Label label1;
	}
}

